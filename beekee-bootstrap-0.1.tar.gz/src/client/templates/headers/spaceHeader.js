Template.spaceHeader.events({

	'click .menu-item': function(e) {
		e.preventDefault();
		var menuItemId = $(e.currentTarget).attr("data-id");
		Session.set('menuItem',menuItemId);
	}
});

Template.spaceHeader.helpers({
	
	authorName: function() {
		if (Session.get(this.space._id).author)
		return Session.get(this.space._id).author; 
	}  
});