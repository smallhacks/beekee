Template.liveFeed.onRendered(function() {

	$('.modal').on('shown.bs.modal', function (e) {
		console.log("ol");
		  $(this).find('[autofocus]').focus();

	});


	this.autorun(function() { // Autorun to reactively update subscription (filtering + interval of loaded posts)

		//var postsToSkip = Session.get('postsToSkip');
		//var postsLimit = Session.get('postsLimit');

		var filters = {spaceId:Session.get('spaceId'), type:"liveFeed"};
		if (Session.get('author') != "")
			filters = {spaceId:Session.get('spaceId'), author:Session.get('author')};
		else if (Session.get('category') != "") {
			filters = {spaceId:Session.get('spaceId'), category:Session.get('category')};
			console.log("nouveau filtre");
		}

 		// Interval of posts subscription : load every posts from "postsToSkip" (skip) to "postsLimit" (limit)
 		// By default, load the 10 last posts (skip : total posts - 10 / limit : 10)
 		// postsLimit (limit) is used to disable reactivity

 	// 	if (!Session.get('isReactive')) 
		// 	subscription = Meteor.subscribe('posts', filters, postsToSkip, postsLimit);
		// 	//subscription = Meteor.subscribe('posts', filters, postsToSkip, postsLimit2);
		// else
		
		//subscription = Meteor.subscribe('posts', {spaceId:Session.get('spaceId'),type:"liveFeed"},{});

		subscription = Meteor.subscribe('posts', filters);
	});
});

Template.liveFeed.helpers({

	liveFeedPosts: function() {
		return Posts.find({},{sort: {submitted: -1}});
	}
});