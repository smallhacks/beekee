Template.liveFeedPost.onCreated(function() {
	imageExtensions = ["jpg","jpeg","png","gif"];
});


Template.liveFeedPost.onRendered(function() {

	$('.post-item--add-comment-textarea').autosize(); // Textarea autosize

	$('#liveFeedPostEdit').on('hide.bs.modal', function (e) {
		Session.set('fileId', false);
		Session.set('fileExt', false);
	})
});


Template.liveFeedPost.events({

	'click .live-feed-post--edit': function(e) {
		e.preventDefault();
		
		var postId = this._id;
		Session.set('postToEdit',postId);
		//Session.set('fileId', false);
		if (Posts.findOne(postId).fileId) {// If image already exist, set fileId + fileExt in session
			Session.set('fileId', Posts.findOne(postId).fileId);
			Session.set('fileExt', Posts.findOne(postId).fileExt);
		}
		$('#liveFeedPostEdit').modal({show:true,backdrop:'static'});

	},
	'click .live-feed-post--delete': function(e) {
		e.preventDefault();
		
		var postId = this._id;
		Session.set('postToDelete',postId);
		$('#liveFeedPostDelete').modal('show');
	},
	'keypress .post-item--add-comment-textarea': function (e, template) {
		if (e.which === 13) {
			e.preventDefault();
			var currentPostId = this._id;
			var comment = $(e.target).val();
			var author = Session.get(Template.parentData(1).space._id).author; 
			if (comment != "") {
				Posts.update(currentPostId, {$push: {comments: {id:Random.id(),author: author, submitted:Date.now(),text:comment}}});
				$(e.target).val('');
			}
		}
	}
	// 'click .post-item--comment-delete': function(e) {
	// 	e.preventDefault();

	// 	var currentPostId = $(e.target).data('postid');
	// 	var currentCommentId = this.id;

	// 	if (confirm(TAPi18n.__('post-item--delete-comment-confirm')))
	// 		Posts.update(currentPostId, {$pull: {comments: {id:currentCommentId}}});
	// },
});

Template.liveFeedPost.helpers({

	image: function() {
		if (this.fileId && $.inArray(this.fileExt, imageExtensions) != -1)
			return this.fileId
	},
	commentEditAllowed: function() {
		if (Template.parentData(2).space.postEditPermissions !== undefined) {
			if (Template.parentData(2).space.postEditPermissions === "all" || (Template.parentData(2).space.postEditPermissions === "own" && Session.get(Template.parentData(2).space._id).author === this.author) || Template.parentData(2).space.userId === Meteor.userId() || Roles.userIsInRole(Meteor.userId(), ['admin']) === true)
				return true
			else
				return false
		}
		else {
			if (Session.get(Template.parentData(2).space._id).author === this.author || Template.parentData(2).space.userId === Meteor.userId() || Roles.userIsInRole(Meteor.userId(), ['admin']) === true)
				return true
			else
				return false
		}
	},
});