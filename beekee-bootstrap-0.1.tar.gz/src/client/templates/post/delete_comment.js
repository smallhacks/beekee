Template.deleteComment.events({

	'click .delete-comment--delete-confirm': function(e) {
		e.preventDefault();

		var currentPostId = Template.parentData(1)._id;
		var currentCommentId = this.id;
		
		Posts.update(currentPostId, {$pull: {comments: {id:currentCommentId}}}, function(error) {
			if (error) {
				alert(TAPi18n.__('error-message')+error.message);
			} else {		
				$('#deleteComment-'+currentCommentId).modal('hide');
			}
		});
	}
});
