(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/uploads.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Upload files with tomitrescak:meteor-uploads                        //
                                                                       //
Meteor.startup(function () {                                           // 3
                                                                       //
	UploadServer.init({                                                   // 5
		tmpDir: process.env.PWD + '/.uploads/tmp',                           // 6
		uploadDir: process.env.PWD + '/.uploads',                            // 7
		checkCreateDirectories: true,                                        // 8
		getDirectory: function (fileInfo, formData) {                        // 9
			return '/';                                                         // 10
		},                                                                   //
		finished: function (fileInfo, formFields) {                          // 12
                                                                       //
			if (fileInfo.name == "box-update.tar") {                            // 14
				cmd = Meteor.wrapAsync(exec);                                      // 15
				res = cmd("mv ../../../../../.uploads/" + fileInfo.name + " ../../../../../updates/");
				res2 = cmd("tar xvf ../../../../../updates/" + fileInfo.name + " -C ../../../../../");
				res3 = cmd("rm ../../../../../updates/" + fileInfo.name);          // 18
				console.log("sur le serveur : " + res2);                           // 19
			}                                                                   //
                                                                       //
			var extension = fileInfo.name.substr(fileInfo.name.lastIndexOf('.') + 1).toLowerCase();
                                                                       //
			if (extension == "jpg" || extension == "jpeg" || extension == "png") {
				// Resize and auto-orient uploaded images with GraphicMagicks      //
				gm(process.env.PWD + '/.uploads/' + fileInfo.name).autoOrient().resize('1200', '1200').write(process.env.PWD + '/.uploads/' + fileInfo.name, Meteor.bindEnvironment(function (error, result) {
					if (error) {                                                      // 27
						console.log("Error when resizing :" + error);                    // 28
					} else {                                                          //
						Files.insert({ fileId: fileInfo.name, fileType: extension });    // 30
					}                                                                 //
				}));                                                               //
			} else Files.insert({ fileId: fileInfo.name, fileType: extension });
		},                                                                   //
		// getFileName: function(fileInfo, formData) {                       //
		// 	// Set a new random file name                                    //
		// 	var extension = fileInfo.name.substr(fileInfo.name.lastIndexOf('.')+1).toLowerCase();
		// 	var newName = Random.id() + '.' + extension;                     //
		// 	return newName;                                                  //
		// },                                                                //
		cacheTime: 0                                                         // 43
	});                                                                   //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=uploads.js.map
