(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['smallhacks:jquery-contextmenu'] = {};

})();

//# sourceMappingURL=smallhacks_jquery-contextmenu.js.map
