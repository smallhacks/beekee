(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/gabrielengel_konecty-magnific-popup/packages/gabrielenge //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gabrielengel:konecty-magnific-popup'] = {};

})();

//# sourceMappingURL=gabrielengel_konecty-magnific-popup.js.map
