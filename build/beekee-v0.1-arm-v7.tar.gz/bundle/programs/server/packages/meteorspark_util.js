(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Util;

(function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/meteorspark_util/packages/meteorspark_util.js                  //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
(function () {                                                             // 1
                                                                           // 2
////////////////////////////////////////////////////////////////////////   // 3
//                                                                    //   // 4
// packages/meteorspark:util/lib/util-server.js                       //   // 5
//                                                                    //   // 6
////////////////////////////////////////////////////////////////////////   // 7
                                                                      //   // 8
// https://github.com/isaacs/inherits/blob/master/inherits_browser.js // 1
Util = Npm.require("util")                                            // 2
                                                                      // 3
////////////////////////////////////////////////////////////////////////   // 12
                                                                           // 13
}).call(this);                                                             // 14
                                                                           // 15
/////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteorspark:util'] = {
  Util: Util
};

})();

//# sourceMappingURL=meteorspark_util.js.map
