(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Slideout;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/chriswessels_slideout/packages/chriswessels_slideout.js  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['chriswessels:slideout'] = {
  Slideout: Slideout
};

})();

//# sourceMappingURL=chriswessels_slideout.js.map
