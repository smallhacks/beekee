(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/ls3271_meteor-linkify/packages/ls3271_meteor-linkify.js  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ls3271:meteor-linkify'] = {};

})();

//# sourceMappingURL=ls3271_meteor-linkify.js.map
