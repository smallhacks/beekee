(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('blog', function (blogId) {                             // 1
	check(blogId, String);                                                // 2
	return Blogs.find({ _id: blogId });                                   // 3
});                                                                    //
                                                                       //
Meteor.publish('allBlogs', function () {                               // 6
	return Blogs.find({});                                                // 7
});                                                                    //
                                                                       //
Meteor.publish('ownBlogs', function (userId) {                         // 10
	return Blogs.find({ userId: userId });                                // 11
});                                                                    //
                                                                       //
Meteor.publish('blogsVisited', function (blogsId) {                    // 14
	return Blogs.find({ "_id": { "$in": blogsId } });                     // 15
});                                                                    //
                                                                       //
Meteor.publish('post', function (postId) {                             // 18
	check(postId, String);                                                // 19
	return Posts.find({ _id: postId });                                   // 20
});                                                                    //
                                                                       //
Meteor.publish('posts', function (filters, skip, limit) {              // 23
	return Posts.find(filters, { sort: { submitted: 1 }, skip: skip, limit: limit });
});                                                                    //
                                                                       //
Meteor.publish("file", function (fileId) {                             // 27
	return Files.find({ fileId: fileId });                                // 28
});                                                                    //
                                                                       //
Meteor.publish("files", function (blogId) {                            // 31
	return Files.find({ blogId: blogId });                                // 32
});                                                                    //
                                                                       //
Meteor.publish("authors", function (blogId) {                          // 35
	return Authors.find({ blogId: blogId });                              // 36
});                                                                    //
                                                                       //
Meteor.publish("categories", function (blogId) {                       // 39
	return Categories.find({ blogId: blogId });                           // 40
});                                                                    //
                                                                       //
Meteor.publish("tags", function (blogId) {                             // 43
	return Tags.find({ blogId: blogId });                                 // 44
});                                                                    //
                                                                       //
Meteor.publish('allUsers', function () {                               // 47
	return Meteor.users.find();                                           // 48
});                                                                    //
                                                                       //
// Publish the current size of a collection without subscribe to the collection
Meteor.publish("count-all-posts", function (blogId) {                  // 52
	var self = this;                                                      // 53
	var count = 0;                                                        // 54
	var initializing = true;                                              // 55
                                                                       //
	var handle = Posts.find({ blogId: blogId }).observeChanges({          // 57
		added: function (doc, idx) {                                         // 58
			count++;                                                            // 59
			if (!initializing) {                                                // 60
				self.changed("counts", blogId, { count: count }); // "counts" is the published collection name
			}                                                                   //
		},                                                                   //
		removed: function (doc, idx) {                                       // 64
			count--;                                                            // 65
			self.changed("counts", blogId, { count: count }); // Same published collection, "counts"
		}                                                                    //
	});                                                                   //
                                                                       //
	initializing = false;                                                 // 70
                                                                       //
	// publish the initial count. `observeChanges` guaranteed not to return
	// until the initial set of `added` callbacks have run, so the `count`
	// variable is up to date.                                            //
	self.added("counts", blogId, { count: count });                       // 75
                                                                       //
	// and signal that the initial document set is now available on the client
	self.ready();                                                         // 78
                                                                       //
	// turn off observe when client unsubscribes                          //
	self.onStop(function () {                                             // 81
		handle.stop();                                                       // 82
	});                                                                   //
});                                                                    //
                                                                       //
Meteor.publish("count-all-pinned", function (blogId) {                 // 87
	var self = this;                                                      // 88
	var pinnedCounts = 0;                                                 // 89
	var initializing = true;                                              // 90
                                                                       //
	var handle = Posts.find({ blogId: blogId, pinned: true }).observeChanges({
		added: function (doc, idx) {                                         // 93
			pinnedCounts++;                                                     // 94
			if (!initializing) {                                                // 95
				self.changed("pinnedCounts", blogId, { count: pinnedCounts }); // "counts" is the published collection name
			}                                                                   //
		},                                                                   //
		removed: function (doc, idx) {                                       // 99
			pinnedCounts--;                                                     // 100
			self.changed("pinnedCounts", blogId, { count: pinnedCounts }); // Same published collection, "counts"
		}                                                                    //
	});                                                                   //
                                                                       //
	initializing = false;                                                 // 105
                                                                       //
	// publish the initial count. `observeChanges` guaranteed not to return
	// until the initial set of `added` callbacks have run, so the `count`
	// variable is up to date.                                            //
	self.added("pinnedCounts", blogId, { count: pinnedCounts });          // 110
                                                                       //
	// and signal that the initial document set is now available on the client
	self.ready();                                                         // 113
                                                                       //
	// turn off observe when client unsubscribes                          //
	self.onStop(function () {                                             // 116
		handle.stop();                                                       // 117
	});                                                                   //
});                                                                    //
                                                                       //
Meteor.publish("count-all-files", function (blogId) {                  // 122
	var self = this;                                                      // 123
	var filesCounts = 0;                                                  // 124
	var initializing = true;                                              // 125
                                                                       //
	//var handle = Posts.find({blogId: blogId, $or : [{fileExt:"txt"},{fileExt:"rtf"},{fileExt:"pdf"},{fileExt:"zip"}]}).observeChanges({
                                                                       //
	var handle = Posts.find({ blogId: blogId, $and: [{ fileId: { $exists: true } }, { fileId: { $ne: false } }, { fileExt: { $nin: ["jpg", "jpeg", "png", "gif"] } }] }).observeChanges({
		added: function (doc, idx) {                                         // 130
			filesCounts++;                                                      // 131
			if (!initializing) {                                                // 132
				self.changed("filesCounts", blogId, { count: filesCounts }); // "counts" is the published collection name
			}                                                                   //
		},                                                                   //
		removed: function (doc, idx) {                                       // 136
			filesCounts--;                                                      // 137
			self.changed("filesCounts", blogId, { count: filesCounts }); // Same published collection, "counts"
		}                                                                    //
	});                                                                   //
                                                                       //
	initializing = false;                                                 // 142
                                                                       //
	// publish the initial count. `observeChanges` guaranteed not to return
	// until the initial set of `added` callbacks have run, so the `count`
	// variable is up to date.                                            //
	self.added("filesCounts", blogId, { count: filesCounts });            // 147
                                                                       //
	// and signal that the initial document set is now available on the client
	self.ready();                                                         // 150
                                                                       //
	// turn off observe when client unsubscribes                          //
	self.onStop(function () {                                             // 153
		handle.stop();                                                       // 154
	});                                                                   //
});                                                                    //
                                                                       //
Meteor.publish("count-all-images", function (blogId) {                 // 159
	var self = this;                                                      // 160
	var imagesCounts = 0;                                                 // 161
	var initializing = true;                                              // 162
                                                                       //
	var handle = Posts.find({ blogId: blogId, $or: [{ fileExt: "jpg" }, { fileExt: "jpeg" }, { fileExt: "gif" }, { fileExt: "png" }] }).observeChanges({
		added: function (doc, idx) {                                         // 165
			imagesCounts++;                                                     // 166
			if (!initializing) {                                                // 167
				self.changed("imagesCounts", blogId, { count: imagesCounts }); // "counts" is the published collection name
			}                                                                   //
		},                                                                   //
		removed: function (doc, idx) {                                       // 171
			imagesCounts--;                                                     // 172
			self.changed("imagesCounts", blogId, { count: imagesCounts }); // Same published collection, "counts"
		}                                                                    //
	});                                                                   //
                                                                       //
	initializing = false;                                                 // 177
                                                                       //
	// publish the initial count. `observeChanges` guaranteed not to return
	// until the initial set of `added` callbacks have run, so the `count`
	// variable is up to date.                                            //
	self.added("imagesCounts", blogId, { count: imagesCounts });          // 182
                                                                       //
	// and signal that the initial document set is now available on the client
	self.ready();                                                         // 185
                                                                       //
	// turn off observe when client unsubscribes                          //
	self.onStop(function () {                                             // 188
		handle.stop();                                                       // 189
	});                                                                   //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
