(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
                                                                       //
	// ###  Mail configuration  ###                                       //
                                                                       //
	//process.env.MAIL_URL = 'smtp://vincent.widmer@beekee.ch:1234512345@mail.infomaniak.com:587/';         
	process.env.MAIL_URL = 'smtp://' + Meteor.settings.mailAddress + ':' + Meteor.settings.mailPassword + '@' + Meteor.settings.mailServer;
	Accounts.emailTemplates.from = "beekee.ch <vincent.widmer@beekee.ch>";
                                                                       //
	// Reset Password mail configuration                                  //
	Accounts.emailTemplates.resetPassword.text = function (user, url) {   // 11
		return "Bonjour, \n\n Vous avez demandé à réinitialiser votre mot de passe.\n\n Si c'est bien le cas, cliquez sur le lien suivant : \n" + url + "\n\n L'équipe beekee.ch";
	};                                                                    //
	Accounts.emailTemplates.resetPassword.subject = function () {         // 16
		return "Réinitialisation de votre mot de passe";                     // 17
	};                                                                    //
                                                                       //
	Accounts.urls.resetPassword = function (token) {                      // 20
		return 'http://beekee.ch/reset-password/' + token;                   // 21
	};                                                                    //
});                                                                    //
                                                                       //
exec = Npm.require('child_process').exec; // No idea what is this ?    // 26
cmd = Meteor.wrapAsync(exec);                                          // 27
                                                                       //
Meteor.methods({                                                       // 30
	sendEmail: function (to, from, subject, text) {                       // 31
		check([to, from, subject, text], [String]);                          // 32
                                                                       //
		// Let other method calls from the same client start running, without waiting for the email sending to complete.
		this.unblock();                                                      // 35
                                                                       //
		Email.send({                                                         // 37
			to: to,                                                             // 38
			from: from,                                                         // 39
			subject: subject,                                                   // 40
			text: text                                                          // 41
		});                                                                  //
	},                                                                    //
	'getIP': function () {                                                // 44
		// Get IP of box                                                     //
		var res;                                                             // 45
		res = cmd("ifconfig eth0 2>/dev/null|awk '/inet addr:/ {print $2}'|sed 's/addr://'");
		return res;                                                          // 47
	},                                                                    //
	'updateBox': function () {                                            // 49
		// Fetch changes from GitHub repository                              //
		var res;                                                             // 50
		res = cmd("git pull origin filtering");                              // 51
		console.log("Updating box : " + res);                                // 52
		return res;                                                          // 53
	},                                                                    //
	'shutdownBox': function () {                                          // 55
		// Shutdown the Raspberry Pi                                         //
		var res;                                                             // 56
		res = cmd("sudo shutdown");                                          // 57
		return res;                                                          // 58
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
