(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/chuangbo_cookie/packages/chuangbo_cookie.js              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['chuangbo:cookie'] = {};

})();

//# sourceMappingURL=chuangbo_cookie.js.map
