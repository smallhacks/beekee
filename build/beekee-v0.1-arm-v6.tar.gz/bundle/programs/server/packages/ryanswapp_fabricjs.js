(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/ryanswapp_fabricjs/packages/ryanswapp_fabricjs.js        //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ryanswapp:fabricjs'] = {};

})();

//# sourceMappingURL=ryanswapp_fabricjs.js.map
