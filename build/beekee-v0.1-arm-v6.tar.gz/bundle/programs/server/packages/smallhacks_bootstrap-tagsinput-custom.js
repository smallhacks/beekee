(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['smallhacks:bootstrap-tagsinput-custom'] = {};

})();

//# sourceMappingURL=smallhacks_bootstrap-tagsinput-custom.js.map
