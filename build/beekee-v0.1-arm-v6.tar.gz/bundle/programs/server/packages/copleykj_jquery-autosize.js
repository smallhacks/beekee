(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/copleykj_jquery-autosize/packages/copleykj_jquery-autosi //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['copleykj:jquery-autosize'] = {};

})();

//# sourceMappingURL=copleykj_jquery-autosize.js.map
